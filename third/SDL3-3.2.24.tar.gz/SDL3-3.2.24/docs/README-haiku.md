# Haiku OS

SDL is fully supported on Haiku OS, and is built using [CMake](README-cmake.md).

