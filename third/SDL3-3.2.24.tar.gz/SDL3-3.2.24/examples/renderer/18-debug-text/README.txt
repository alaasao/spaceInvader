This example creates an SDL window and renderer, and draws some text
using SDL_RenderDebugText(). This is not quality text rendering, but it can
be helpful for simple apps, debugging, or showing something in a pinch.

