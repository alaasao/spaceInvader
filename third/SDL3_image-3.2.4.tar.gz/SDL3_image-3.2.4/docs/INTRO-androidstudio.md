
# Introduction to SDL_image with Android Studio

A complete example is available at:

https://github.com/Ravbug/sdl3-sample

Support for AVIF, JPEG-XL, TIFF, and WebP are not included by default because of the size of the decode libraries, but you can get them by running external/download.sh and then editing the config at the top of Android.mk to enable them.
